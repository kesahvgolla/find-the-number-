// Declaring variables

// Game function