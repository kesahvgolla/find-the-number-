const $resetButton=document.getElementById("reset");
$resetButton.onclick=()=>{
    location.href="./game.html";
};